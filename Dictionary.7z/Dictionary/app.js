var express =  require('express');
//var expressSession = require("express-session");
var app = new express();
var fs = require('fs');
var bodyParser = require("body-parser");

var isLoggedIn = false;
var wordObj = {};
var words;
fs.readFile("./data/words.json", "utf8", function(error, data) {
	if (error) {
		console.log("server failed reading json!")
		return;
	}
	words = JSON.parse(data.trim());
});
var users;
fs.readFile("./data/user.json", "utf8", function(error, data) {
	if (error) {
		console.log("server failed reading json!")
		return;
	}
	users = JSON.parse(data.trim());
});

// middlewares
app.use("/admin", function(req, res, next) {
	if (!isLoggedIn) {
		res.redirect("/login.html");
	}
	next();
});
app.use("/admin/edit.html", function(req, res, next) {
	console.log("jkjj")
	var wordValue = req.query["word"];
	if (wordValue == undefined) {
		res.header("Content-Type: text/html");
		res.status(404).send("Oops something went wrong!");
		res.end()
	}
	wordValue = String(wordValue).toUpperCase().trim();
	var wordMeaning = words[wordValue];
	if (wordMeaning == undefined || wordMeaning === null) {
		res.header("Content-Type: text/html");
		res.status(200).send("Oops no matching word!");
		res.end();
		return;
	}
	// setting the global wordObj
	wordObj.value = wordValue;
	wordObj.meaning = wordMeaning;
	next();
});
//app.use(session({secret: "Your secret key"}));
app.use(express.static("public"));
app.use(express.static("node_modules/bootstrap/dist/"));
app.use(bodyParser.urlencoded( {extended: true } ));
app.use("/admin/edit/:word", function(req,res,next) {
	var wordValue = String(req.params.word).toUpperCase().trim();
	var wordMeaning = words[wordValue];
	if (wordMeaning == undefined || wordMeaning === null) {
		res.header("Content-Type: text/html");
		res.status(200).send("Oops no matching word!");
		res.end();
		return;
	}
	// setting the global wordObj
	 wordObj.value = wordValue;
	 wordObj.meaning = wordMeaning;
	next();
});



//Get method
app.get("/findWord/:word", function(req, res) {
	var reqWord = req.params.word.toUpperCase().trim();
	var message= "Unknown Word";
	for (var word in words) {
		if (word == reqWord) {
			message = words[word];
			break;
		}
	}
	res.header("Content-Type: text/plain");
	console.log(message);
    res.status(200).send(message);
})

app.get("/autoFill/:word", function(req, res) {
	var filterWord = [];
	var reqWord = req.params.word.toUpperCase().trim();
	for (var word in words) {
		if (word.startsWith(reqWord)) {
			filterWord.push(word);
		}
	}
	console.log(filterWord)
	res.header("Content-Type: applicatioin/json");
	res.status(200).send(filterWord);
});

app.get("/listWords", function(req, res) {
	res.header("Content-Type: applicatioin/json");
	res.status(200).send(words);
});
app.get("/admin/remove/:word", function(req, res) {
	var deletedWord = String(req.params.word).toUpperCase().trim();
	console.log(deletedWord);
	delete words[deletedWord];
	fs.writeFile("./data/words.json", JSON.stringify(words), function(error, data) {
		if (error) {
			console.log("server failed updating json!")
			return;
		}
		
	});
	res.redirect("/admin/words.html");
});

app.get("/admin/removeAll", function(req, res) {
	for (var word in words) {
		delete words[word];
	}
	fs.writeFile("./data/words.json", JSON.stringify(words), function(error, data) {
		if (error) {
			console.log("server failed updating json!")
			return;
		}
		
	});
	res.redirect("/admin/words.html");
});

app.get("/admin/edit/:word", function(req, res) {
	res.redirect("/admin/edit.html?word=" + req.params.word);
});

app.get("/admin/getWord", function(req, res) {
	res.header("Content-Type: applicatioin/json");
	res.status(200).send(wordObj);
	console.log(wordObj);
	wordObj = {}; // resetting wordObj to null;

});
app.get("/admin/logout", function(req, res) {
	if (isLoggedIn){
		isLoggedIn = false;
		res.redirect("/index.html");
	}
})
app.get("/admin/listUsers", function(req, res) {
	var userNameArr = [];
	for (var index in users) {
		userNameArr.push(users[index]["userName"]);
	}
	res.header("Content-Type: applicatioin/json");
	res.status(200).send(userNameArr);
});

// Post
app.post("/admin/addWord", function(req, res) {
	var addedWord = String(req.body.word).toUpperCase().trim();
	var addedMeaning = String(req.body.meaning);
	words[addedWord] = addedMeaning;
	fs.writeFile("./data/words.json", JSON.stringify(words), function(error, data) {
		if (error) {
			console.log("server failed updating json!")
			return;
		}
		
	});
	res.redirect("/admin/words.html");
});
app.post("/admin/edit/:word", function(req, res) {
	var editeddWord = wordObj.value;
	console.log(editeddWord)
	var meaning = String(req.body.meaning);
	words[editeddWord] = meaning;
	wordObj = {}; // resetting wordObj to null;
	fs.writeFile("./data/words.json", JSON.stringify(words), function(error, data) {
		if (error) {
			console.log("server failed updating json!")
			return;
		}
		
	});
	res.redirect("/admin/words.html");
});

app.post("/login", function(req, res) {
	var password = req.body.password;
	var userName = req.body.userName;
	if (password == undefined || password == null|| userName == undefined || userName == null) {
		res.redirect("/login.html"); // this has to be to an error page
		return;
	}
	var user = users.filter(u => (u.userName === userName && u.password === password));
	console.log(user);
	console.log(user);
	if (user.length !== 0 && user !== null && user!== undefined) {
		isLoggedIn = true;
		res.redirect("/admin/words.html")
	} else {
		res.header("Content-Type: text/plain");
		res.status(400).send("Authorization error!");	
	}

});
app.post("/admin/addUser", function(req, res) {
	var user = { 
		"userName":String(req.body.userName),
		"password":String(req.body.password)

	}
	users.push(user);
	fs.writeFile("./data/user.json", JSON.stringify(users), function(error, data) {
		if (error) {
			console.log("server failed reading json!")
			return;
		}
		
	});
	res.redirect("/admin/users.html");
});

app.listen(3000, function() {
	console.log("server listining on port 3000!")
});


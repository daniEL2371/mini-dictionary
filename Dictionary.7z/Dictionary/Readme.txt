This is a client server architecture.
This a demo dictionary app with my orginal code.
The server side is written with node/ express.js.
Any user can search for a word, and if found the discription is returned.
A user with admin privilage can add edit or delete a word and also can add another user with admin privilage.







